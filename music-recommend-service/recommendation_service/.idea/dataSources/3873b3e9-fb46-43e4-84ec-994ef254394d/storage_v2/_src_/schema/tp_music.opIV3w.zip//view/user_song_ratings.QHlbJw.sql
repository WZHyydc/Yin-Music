create definer = root@`%` view user_song_ratings as
select `r`.`consumer_id`                                                                          AS `consumer_id`,
       `ls`.`song_id`                                                                             AS `song_id`,
       (sum((`r`.`score` / `song_list_count`.`song_count`)) / count(distinct `r`.`song_list_id`)) AS `weighted_score`
from ((`tp_music`.`rank_list` `r` join `tp_music`.`list_song` `ls`
       on ((`r`.`song_list_id` = `ls`.`song_list_id`))) join (select `tp_music`.`list_song`.`song_list_id` AS `song_list_id`,
                                                                     count(0)                              AS `song_count`
                                                              from `tp_music`.`list_song`
                                                              group by `tp_music`.`list_song`.`song_list_id`) `song_list_count`
      on ((`ls`.`song_list_id` = `song_list_count`.`song_list_id`)))
group by `r`.`consumer_id`, `ls`.`song_id`;

