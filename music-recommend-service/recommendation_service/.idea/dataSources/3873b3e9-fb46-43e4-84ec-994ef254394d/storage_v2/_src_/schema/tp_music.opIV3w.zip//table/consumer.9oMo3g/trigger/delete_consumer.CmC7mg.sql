create definer = root@`%` trigger delete_consumer
    after delete
    on consumer
    for each row
BEGIN
    DELETE FROM comment WHERE user_id = OLD.id;
END;

